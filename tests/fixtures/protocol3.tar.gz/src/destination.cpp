#include "destination.h"
#include <fcntl.h>
#include <filesystem>
#include <cerrno>
#include <algorithm>
#ifdef __APPLE__
#include <sys/clonefile.h>
#endif

namespace {
int root_fd = -1;
std::string root_path;
std::string absolute(const std::string& path) {
  std::error_code error;
  auto p = std::filesystem::absolute(path.empty() ? "." : path, error);
  if (error) { errno = error.value(); return {}; }
  auto result = p.lexically_normal().string();
  while (result.size() > 1 && result.back() == '/') result.pop_back();
  return result;
}
int walk(int fd, const std::filesystem::path& rel) {
  for (const auto& component : rel) {
    auto name = component.string();
    if (name.empty() || name == ".") continue;
    if (name == "..") { close(fd); errno = EPERM; return -1; }
    int next = openat(fd, name.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    int error = errno;
    close(fd);
    if (next < 0) { errno = error; return -1; }
    fd = next;
  }
  return fd;
}
}

bool anchor_destination(const std::string& path) {
  if (root_fd >= 0) return true;
  std::string existing = absolute(path);
  if (existing.empty()) return false;
  struct stat st;
  while (stat(existing.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) {
    auto parent = std::filesystem::path(existing).parent_path().string();
    if (parent.empty() || parent == existing) return false;
    existing = std::move(parent);
  }
  for (;;) {
    std::error_code error;
    auto resolved = std::filesystem::canonical(existing, error);
    if (error) { errno = error.value(); return false; }
    int fd = open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (fd < 0) return false;
    fd = walk(fd, resolved.relative_path());
    if (fd >= 0) {
      root_path = existing;
      root_fd = fd;
      return true;
    }
    // A mode-000 destination can be repaired through its accessible parent.
    // Descendant operations still use NOFOLLOW from that pinned parent.
    if (errno != EACCES) return false;
    auto parent = std::filesystem::path(existing).parent_path().string();
    if (parent.empty() || parent == existing) return false;
    existing = std::move(parent);
  }
}

DestPath destination_path(const std::string& path) {
  auto p = absolute(path);
  if (root_fd < 0 || p.empty() || (p != root_path &&
      !(p.starts_with(root_path) && (root_path == "/" || p[root_path.size()] == '/')))) {
    errno = EPERM;
    return {};
  }
  std::filesystem::path rel = std::filesystem::path(p).lexically_relative(root_path);
  auto name = rel.filename().string();
  if (name.empty()) name = ".";
  int fd = dup(root_fd);
  if (fd < 0) return {};
  fd = walk(fd, rel.parent_path());
  if (fd < 0) return {};
  return {fd, std::move(name)};
}

int destination_open_dir(const char* path) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : openat(p.fd, p.name.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
}
int destination_stat(const char* path, struct stat* st) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : fstatat(p.fd, p.name.c_str(), st, AT_SYMLINK_NOFOLLOW);
}
int destination_chmod(const char* path, mode_t mode) {
  auto p = destination_path(path);
  if (p.fd < 0) return -1;
  if (p.name == ".") return fchmod(p.fd, mode);
#ifndef __APPLE__
  // Linux fchmodat(AT_SYMLINK_NOFOLLOW) is not available on older kernels.
  // Pin regular files/directories with O_NOFOLLOW, then change that object.
  struct stat st;
  if (fstatat(p.fd, p.name.c_str(), &st, AT_SYMLINK_NOFOLLOW) != 0) return -1;
  if (S_ISLNK(st.st_mode)) return 0; // Linux symlink modes are always 0777.
  int fd = openat(p.fd, p.name.c_str(), O_PATH | O_NOFOLLOW | O_CLOEXEC);
  if (fd < 0) return -1;
  if (fstat(fd, &st) != 0 || S_ISLNK(st.st_mode)) { close(fd); errno = ELOOP; return -1; }
  // /proc/self/fd names the pinned object, including mode-000 files and devices,
  // and does not re-resolve the receiver-owned pathname.
  std::string pinned = "/proc/self/fd/" + std::to_string(fd);
  int result = chmod(pinned.c_str(), mode), error = errno;
  close(fd);
  errno = error;
  return result;
#else
  return fchmodat(p.fd, p.name.c_str(), mode, AT_SYMLINK_NOFOLLOW);
#endif
}
int destination_chown(const char* path, uid_t uid, gid_t gid) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : p.name == "." ? fchown(p.fd, uid, gid) :
    fchownat(p.fd, p.name.c_str(), uid, gid, AT_SYMLINK_NOFOLLOW);
}
int destination_times(const char* path, const timespec times[2]) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : p.name == "." ? futimens(p.fd, times) :
    utimensat(p.fd, p.name.c_str(), times, AT_SYMLINK_NOFOLLOW);
}
int destination_mkdir(const char* path, mode_t mode) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : mkdirat(p.fd, p.name.c_str(), mode);
}
int destination_unlink(const char* path) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : unlinkat(p.fd, p.name.c_str(), 0);
}
int destination_rmdir(const char* path) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : unlinkat(p.fd, p.name.c_str(), AT_REMOVEDIR);
}
int destination_symlink(const char* target, const char* path) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : symlinkat(target, p.fd, p.name.c_str());
}
ssize_t destination_readlink(const char* path, char* buf, size_t size) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : readlinkat(p.fd, p.name.c_str(), buf, size);
}
int destination_mknod(const char* path, mode_t mode, dev_t dev) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : mknodat(p.fd, p.name.c_str(), mode, dev);
}
int destination_mkfifo(const char* path, mode_t mode) {
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : mkfifoat(p.fd, p.name.c_str(), mode);
}
int destination_clone(const char* source, const char* path, unsigned flags) {
#ifdef __APPLE__
  auto p = destination_path(path);
  return p.fd < 0 ? -1 : clonefileat(AT_FDCWD, source, p.fd, p.name.c_str(), flags);
#else
  errno = ENOTSUP;
  return -1;
#endif
}

bool unsafe_link(std::string_view target, std::string_view parent) {
  if (target.empty() || target.front() == '/') return true;
  int depth = parent.empty() ? 0 : 1 + std::count(parent.begin(), parent.end(), '/');
  size_t start = 0;
  while (start <= target.size()) {
    size_t end = target.find('/', start);
    if (end == std::string_view::npos) end = target.size();
    auto component = target.substr(start, end - start);
    if (component == "..") { if (!depth) return true; depth--; }
    else if (!component.empty() && component != ".") depth++;
    start = end + 1;
  }
  return false;
}
